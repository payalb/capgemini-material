package com.capgemini.mw.service;

import java.util.List;

import com.capgemini.mw.bean.MovieBean;
import com.capgemini.mw.dao.MovieDAO;
import com.capgemini.mw.dao.MovieDAOImpl;
import com.capgemini.mw.exception.MovieException;

public class MovieServiceImpl implements MovieService {
	MovieDAO dao = new MovieDAOImpl();

	@Override
	public List<MovieBean> getAllMovies() throws MovieException {

		return dao.getAllMovies();

	}

	public void makeBooking(int seatBook, String showId) throws MovieException {
		dao.makeBooking(seatBook, showId);
	}

}
