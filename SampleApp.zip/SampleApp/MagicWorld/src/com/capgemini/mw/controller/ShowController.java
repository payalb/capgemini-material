package com.capgemini.mw.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.mw.bean.MovieBean;
import com.capgemini.mw.exception.MovieException;
import com.capgemini.mw.service.MovieServiceImpl;

/**
 * Servlet implementation class ShowController
 */
@WebServlet("*.obj")
public class ShowController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private HttpSession session;
	private String target = "";

	private String targetSuccess = "success.jsp";
	private String targetViewAll = "showDetails.jsp";
	private String targetError = "error.jsp";
	private String targetHome = "index.jsp";
	private String targetBook = "bookNow.jsp";

	MovieServiceImpl movieService = new MovieServiceImpl();

	// Mandatory as some jsps may be sending post data
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		
		String path = request.getServletPath().trim();

		switch (path) {
		case "/Home.obj":
			target = targetHome;
			break;

		case "/showDetails.obj":
			// Better to initialize it to prevent nullpointer exception
			// clear the previous session. Treat as a new request
			request.getSession().invalidate();
			// Create new session
			session = request.getSession(true);
			List<MovieBean> movieList = new ArrayList<>();
			try {
				movieList = movieService.getAllMovies();
			} catch (MovieException e) {
				session.setAttribute("error", e.getMessage());
				target = targetError;
			}
			if (!movieList.isEmpty()) {
				session.setAttribute("error", null);
				session.setAttribute("movieList", movieList);
				target = targetViewAll;

			}
			// If error was populated through exception at line 62, not to
			// overwrite it.
			else if (session.getAttribute("error") == null) {
				session.setAttribute("movieList", null);
				session.setAttribute("error", "Sorry No data Found!");
				target = targetViewAll;
			}

			break;

		case "/bookNow.obj":
			session.setAttribute("name", request.getParameter("name"));
			session.setAttribute("price", request.getParameter("price"));
			session.setAttribute("showId", request.getParameter("showId"));
			session.setAttribute("avSeats", request.getParameter("avSeats"));
			target = targetBook;
			break;

		case "/success.obj":

			String custName = request.getParameter("custname");
			String mobno = request.getParameter("mobno");
			Integer seatBook = Integer.parseInt(request
					.getParameter("seatBook"));
			String showId = (String) session.getAttribute("showId");
			session.setAttribute("custName", custName);
			session.setAttribute("mobno", mobno);
			session.setAttribute("seatBook", seatBook);
			try {
				movieService.makeBooking(seatBook, showId);
			} catch (MovieException e) {
				session.setAttribute("error", e.getMessage());
				target = targetError;
			}
			target = targetSuccess;
			break;
		default:
			session.setAttribute("error", "Invalid URL!!");
			target = targetError;
		}

		RequestDispatcher dispatcher = request.getRequestDispatcher(target);
		dispatcher.forward(request, response);
	}

}
