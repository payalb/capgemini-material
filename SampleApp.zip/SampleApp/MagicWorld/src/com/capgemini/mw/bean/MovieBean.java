package com.capgemini.mw.bean;

import java.io.Serializable;
import java.time.LocalDate;
//should implement serializable
public class MovieBean implements Serializable{
	
	private static final long serialVersionUID = 1L;
	
	private String showId;
	private String showName;
	private String location;
	private LocalDate showDate;
	private int avSeats;
	private double priceTicket;
	
	//Default Constructor mandatory
	public MovieBean()
	{
		super();
	}

	//Parameterized Constructor
	public MovieBean(String showId, String showName, String location,
			 int avSeats, double priceTicket) {
		super();
		this.showId = showId;
		this.showName = showName;
		this.location = location;
		
		this.avSeats = avSeats;
		this.priceTicket = priceTicket;
	}

	public String getShowId() {
		return showId;
	}

	public void setShowId(String showId) {
		this.showId = showId;
	}

	public String getShowName() {
		return showName;
	}

	public void setShowName(String showName) {
		this.showName = showName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public LocalDate getShowDate() {
		return showDate;
	}

	public void setShowDate(LocalDate showDate) {
		this.showDate = showDate;
	}

	public int getAvSeats() {
		return avSeats;
	}

	public void setAvSeats(int avSeats) {
		this.avSeats = avSeats;
	}

	public double getPriceTicket() {
		return priceTicket;
	}

	public void setPriceTicket(double priceTicket) {
		this.priceTicket = priceTicket;
	}

	@Override
	public String toString() {
		return "MovieBean [showId=" + showId + ", showName=" + showName
				+ ", location=" + location + ", showDate=" + showDate
				+ ", avSeats=" + avSeats + ", priceTicket=" + priceTicket + "]";
	}
	
	

	
}
