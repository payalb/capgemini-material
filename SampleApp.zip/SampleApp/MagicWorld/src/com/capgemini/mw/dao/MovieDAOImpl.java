package com.capgemini.mw.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.mw.bean.MovieBean;
import com.capgemini.mw.exception.MovieException;
import com.capgemini.mw.utility.DbConnection;

public class MovieDAOImpl implements MovieDAO {

	// ------------------------ 1. Movie Application --------------------------
	/*******************************************************************************************************
	 * - Function Name : getAllMovies() - Input Parameters : - Return Type :
	 * List - Throws : MovieException - Author : CAPGEMINI - Creation Date :
	 * 25/09/2017 - Description : return list
	 ********************************************************************************************************/
	@Override
	public List<MovieBean> getAllMovies() throws MovieException {

		List<MovieBean> list = new ArrayList<MovieBean>();
		// Used try with resource block.No need of closing resources manually
		try (Connection conn = DbConnection.getConnection();
		// Used statement, no need of prepared statement
				Statement statement = conn.createStatement();
				ResultSet resultSet = statement
						.executeQuery(QueryMapper.VIEWALL);) {
			while (resultSet.next()) {
				// Should create bean object inside the loop
				MovieBean dto = new MovieBean();
				dto.setShowId(resultSet.getString(1));
				dto.setShowName(resultSet.getString(2));
				dto.setLocation(resultSet.getString(3));
				dto.setShowDate(resultSet.getDate(4).toLocalDate());
				dto.setAvSeats(resultSet.getInt(5));
				dto.setPriceTicket(resultSet.getDouble(6));
				list.add(dto);
			}
		} catch (SQLException e) {
			throw new MovieException("dao/sql/ERROR:" + e.getMessage());
		} catch (Exception e) {
			throw new MovieException("ERROR:" + e.getMessage());
		}
		return list;
	}

	// ------------------------ 1. Movie Application --------------------------
	/*******************************************************************************************************
	 * - Function Name : makeBooking() - Input Parameters : int seatBook,String
	 * showId - Return Type : void - Throws : MovieException - Author :
	 * CAPGEMINI - Creation Date : 25/09/2017 - Description : Updates available
	 * seats after booking in database.
	 ********************************************************************************************************/
	@Override
	public void makeBooking(int seatBook, String showId) throws MovieException {

		try (
			Connection conn = DbConnection.getConnection();
			PreparedStatement preparedStatement = conn.prepareStatement(QueryMapper.UPDATE);){
			preparedStatement.setInt(1, seatBook);
			preparedStatement.setString(2, showId);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			throw new MovieException("Error while database interaction:::"
					+ e.getMessage());
		}

	}

}
