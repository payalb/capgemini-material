package com.capgemini.mw.controller;

import java.io.IOException;

import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.mw.bean.MovieBean;
import com.capgemini.mw.exception.MovieException;
import com.capgemini.mw.service.MovieServiceImpl;



/**
 * Servlet implementation class ShowController
 */
@WebServlet("*.obj")
public class ShowController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ShowController() {
        super();
        
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		MovieServiceImpl movieService = null;
		MovieBean dto = null;
		String target = "";
		PrintWriter out = response.getWriter();
		

		HttpSession session = request.getSession(true);
		// Object creations
		dto =  new MovieBean();
		movieService = new MovieServiceImpl();
	
		
		String targetSuccess = "success.jsp";
		
		String targetViewAll = "showDetails.jsp";
		String targetError = "error.jsp";
		String targetHome = "index.jsp";
		String targetBook = "bookNow.jsp";
		
	

		String path = request.getServletPath().trim();

		switch (path) {

		case "/Home.obj":
			session.setAttribute("error", null);
			session.setAttribute("dto", null);
			target = targetHome;
			break;
			
		
		case "/showDetails.obj":
			List<MovieBean> movieList = null;
			try {
				movieList = movieService.getAllMovies();
			} catch (MovieException e) {
				session.setAttribute("error", e.getMessage());
				target = targetError;
			}
			if (!movieList.isEmpty()) {
				session.setAttribute("error", null);
				session.setAttribute("movieList", movieList);
				target = targetViewAll;
				
				
			} else {
				session.setAttribute("movieList", null);
				session.setAttribute("error", "Sorry No data Found!");
				target = targetViewAll;
				
			}

			break;
		
		
		case "/bookNow.obj":
			session.setAttribute("name", request.getParameter("name"));
			session.setAttribute("price", request.getParameter("price"));
			session.setAttribute("showId", request.getParameter("showId"));
			session.setAttribute("avSeats", request.getParameter("avSeats"));
			target = targetBook;
			break;
			
		case "/success.obj":
			
			String custName = request.getParameter("custname");
			String mobno = request.getParameter("mobno");
			Integer seatBook = Integer.parseInt(request.getParameter("seatBook"));
			String showId=(String)session.getAttribute("showId");
			session.setAttribute("custName",custName);
			session.setAttribute("mobno",mobno);
			session.setAttribute("seatBook",seatBook);
			//System.out.println(trainId);
			try{
				movieService.makeBooking(seatBook,showId);
			}
			catch (MovieException e1)
			{
				e1.printStackTrace();
			}
			target=targetSuccess;
			break;
		
		
		
		
		}
		

		RequestDispatcher dispatcher = request.getRequestDispatcher(target);
		dispatcher.forward(request, response);
	}
	
		
	}


