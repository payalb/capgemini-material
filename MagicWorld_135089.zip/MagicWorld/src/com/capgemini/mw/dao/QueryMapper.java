package com.capgemini.mw.dao;

public interface QueryMapper {
	String VIEWALL = "SELECT showid,showname,location,showdate,avseats,priceticket  FROM ShowDetails";
	String UPDATE = "UPDATE showdetails SET avseats=avseats-? WHERE showId=?";

}
