SELECT * from EMP824177;

insert into emp824177 values(2,'Anju',90000);